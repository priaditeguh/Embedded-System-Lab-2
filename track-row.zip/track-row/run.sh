#!/bin/bash

/home/root/powercycle.sh
./tracking tracking.out car.avi

